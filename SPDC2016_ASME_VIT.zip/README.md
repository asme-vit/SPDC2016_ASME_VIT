# SPDC2016_ASME_VIT
Student Professional Development Conference(SPDC) 2016 - The American Society of Mechanical Engineers(ASME)-VIT,vellore WEBSITE
