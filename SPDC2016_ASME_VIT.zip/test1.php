<html>
<title>check payment</title>
<body>
<form action="spdc_ret.php" method="POST">
<input type="text" name="Refno" placeholder="Refno" required>
<br>
<input type="text" name="tpsltranid" placeholder="tpsltranid" required>
<br>
<input type="text" name="bankrefno" placeholder="bankrefno" required>
<br>
<input type="text" name="txndate" placeholder="txndate" required>
<br>
<input type="text" name="status" placeholder="status" required>
<br>
<input type="submit" name="submit">
</form>
</body>
</html>